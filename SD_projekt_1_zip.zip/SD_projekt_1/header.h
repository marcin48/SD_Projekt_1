#pragma once
#include<iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int data) : data(data), next(nullptr), prev(nullptr) {}
    ~Node() {};
};

class ArrayList
{
private:
    int* arr;
    int size;
    int end;

public:
    ArrayList();
    ~ArrayList();

    void insert_front(int data);
    void insert(int index, int data);
    void insert_back(int data);
    void remove(int index);
    int search(int data)const;
    void print();
    // test czy dziala pushowanie kodu 

};


class Linked_list_h {

private:
    Node* head;
    int size;

public:
    Linked_list_h() : head(nullptr), size(0) {};
    ~Linked_list_h() {};

    void Add_First(int value);
    void Add_End(int value);
    void Remove_First();
    void Remove_End();
    void Add_Random(int value, int id);
    void Remove_Random(int id);
    void Look_For(int value);
    void Show();
    int Size_of_list()const;

};

class Linked_list_ht {

private:
    Node* head;
    Node* tail;
    int size;

public:
    Linked_list_ht() : head(nullptr), tail(nullptr), size(0) {};
    ~Linked_list_ht() {};

    void Add_First(int value);
    void Add_End(int value);
    void Remove_First();
    void Remove_End();
    void Look_For(int value);
    void Add_Random(int value, int id);
    void Remove_Random(int id);
    void Show();
    int Size_of_list()const;

};

void Test_linked_list_ht();
void Test_linked_list_h();
void Test_arraylist();