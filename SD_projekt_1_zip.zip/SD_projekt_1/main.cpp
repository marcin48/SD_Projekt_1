#include<iostream>
#include"header.h"
using namespace std;

int main() {
	Test_linked_list_ht();
	Test_linked_list_h();
	Test_arraylist();

	return 0;
}