#include "header.h"

void Test_linked_list_ht() {
    Linked_list_ht list;
    cout << "-----------------------------------------------" << endl;
    cout << "Test linked list head and tail: " << endl;
    list.Add_End(1);
    list.Add_End(2);
    list.Add_End(3);
    list.Add_First(4);
    list.Add_First(5);
    list.Add_Random(98, 2);
    list.Remove_Random(2);
    list.Show();
    cout << "Rozmiar listy: " << list.Size_of_list() << endl;
    list.Remove_End();
    list.Remove_First();
    list.Show();
    cout << "Rozmiar listy: " << list.Size_of_list() << endl;
    list.Look_For(4);
    list.Look_For(6);
    cout << "-----------------------------------------------" << endl;
}

void Test_linked_list_h() {

    Linked_list_h list;

    cout << "-----------------------------------------------" << endl;
    cout << "Test linked list head: " << endl;

    list.Add_First(1);
    list.Add_First(2);
    list.Add_First(3);
    list.Add_End(4);
    list.Add_End(5);
    list.Add_Random(98, 3);
    list.Show();
    list.Remove_Random(4);
    //list.Remove_First();
    //list.Remove_End();
    list.Look_For(4);
    list.Show();
    cout << "Liczba element�w w li�cie: " << list.Size_of_list() << endl;
    cout << "-----------------------------------------------" << endl;
}

void Test_arraylist() {

    ArrayList array;

    cout << "-----------------------------------------------" << endl;
    cout << "Test array list: " << endl;

    array.insert_front(1);
    array.insert_front(2);
    array.insert_front(3);
    array.insert_front(6);
    array.insert_back(4);
    array.insert_back(6);
    array.insert(3,78);
    array.print();
    array.remove(1);
    array.remove(13);
    cout << "Value: " << array.search(5) << endl;
    array.print();
    cout << "-----------------------------------------------" << endl;



}